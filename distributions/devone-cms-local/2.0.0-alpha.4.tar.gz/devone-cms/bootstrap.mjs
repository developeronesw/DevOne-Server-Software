// adapters/local/runtime.ts
import { constants } from "node:fs";
import { mkdir as mkdir2, lstat, open, chmod } from "node:fs/promises";
import { resolve as resolve3 } from "node:path";
import { randomBytes } from "node:crypto";
import { DatabaseSync } from "node:sqlite";

// adapters/local/providers.ts
import { mkdir, readFile, writeFile, unlink, stat, access } from "node:fs/promises";
import { dirname, resolve, relative, isAbsolute, sep } from "node:path";
var LocalDatabase = class {
  constructor(db) {
    this.db = db;
  }
  db;
  async first(sql, ...params) {
    return this.db.prepare(sql).get(...params) ?? null;
  }
  async all(sql, ...params) {
    return this.db.prepare(sql).all(...params);
  }
  async run(sql, ...params) {
    const r = this.db.prepare(sql).run(...params);
    return { changes: Number(r.changes), lastInsertId: Number(r.lastInsertRowid) };
  }
  async batch(statements) {
    this.db.exec("BEGIN IMMEDIATE;");
    try {
      for (const s of statements) this.db.prepare(s.sql).run(...s.params ?? []);
      this.db.exec("COMMIT;");
    } catch (error) {
      try {
        this.db.exec("ROLLBACK;");
      } catch {
      }
      throw error;
    }
  }
};
var LocalCache = class {
  values = /* @__PURE__ */ new Map();
  async get(key) {
    const hit = this.values.get(key);
    if (!hit) return null;
    if (hit.expires !== null && hit.expires <= Date.now()) {
      this.values.delete(key);
      return null;
    }
    return hit.value;
  }
  async set(key, value, ttlSeconds) {
    this.values.set(key, { value, expires: ttlSeconds && ttlSeconds > 0 ? Date.now() + ttlSeconds * 1e3 : null });
  }
  async delete(key) {
    this.values.delete(key);
  }
};
var LocalMedia = class {
  root;
  constructor(root) {
    this.root = resolve(root);
  }
  safe(key) {
    const normalized = key.replace(/\\/g, "/").replace(/^\/+/, "");
    const path = resolve(this.root, normalized);
    const rel = relative(this.root, path);
    if (isAbsolute(rel) || rel.startsWith(".." + sep) || rel === "..") throw new Error("Invalid media key.");
    return path;
  }
  async put(key, body, options = {}) {
    const path = this.safe(key);
    await mkdir(dirname(path), { recursive: true });
    let data;
    if (typeof body === "string") data = new TextEncoder().encode(body);
    else if (body instanceof Uint8Array) data = body;
    else if (body instanceof ArrayBuffer) data = new Uint8Array(body);
    else data = new Uint8Array(await new Response(body).arrayBuffer());
    await writeFile(path, data);
    const info = await stat(path);
    return { key, contentType: options.contentType ?? "", size: info.size, metadata: options.metadata };
  }
  async get(key) {
    try {
      return new Response(await readFile(this.safe(key)));
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  }
  async delete(key) {
    try {
      await unlink(this.safe(key));
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
  }
  async exists(key) {
    try {
      await access(this.safe(key));
      return true;
    } catch {
      return false;
    }
  }
};
function createLocalServices(options) {
  return {
    db: new LocalDatabase(options.database),
    cache: new LocalCache(),
    media: new LocalMedia(options.mediaDir),
    config: {
      runtime: "local",
      password_hash_iterations: options.environment === "production" ? 6e5 : 1e4,
      environment: options.environment ?? "development",
      media_dir: options.mediaDir,
      secret_key: options.secretKey ?? ""
    }
  };
}

// adapters/local/migrations.ts
import { readdir, readFile as readFile2 } from "node:fs/promises";
import { resolve as resolve2 } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
async function runLocalMigrations(db, migrationsDir = process.env.DEVONE_MIGRATIONS_DIR ? pathToFileURL(resolve2(process.env.DEVONE_MIGRATIONS_DIR) + "/") : new URL("../../migrations/", import.meta.url)) {
  db.exec("CREATE TABLE IF NOT EXISTS devone_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);");
  const dirPath = resolve2(fileURLToPath(migrationsDir));
  const names = (await readdir(dirPath)).filter((n) => /^\d+_.+\.sql$/.test(n)).sort();
  for (const name of names) {
    const exists = db.prepare("SELECT name FROM devone_migrations WHERE name=?1").get(name);
    if (exists) continue;
    const sql = await readFile2(resolve2(dirPath, name), "utf8");
    db.exec("BEGIN IMMEDIATE;");
    try {
      db.exec(sql);
      db.prepare("INSERT INTO devone_migrations(name) VALUES(?1)").run(name);
      db.exec("COMMIT;");
    } catch (error) {
      try {
        db.exec("ROLLBACK;");
      } catch {
      }
      ;
      throw new Error("Migration failed: " + name, { cause: error });
    }
  }
}

// adapters/local/runtime.ts
async function loadSecret(dataDir, supplied) {
  if (supplied) {
    if (!/^[a-zA-Z0-9_-]{43}$/.test(supplied)) throw Error("Invalid runtime key.");
    return supplied;
  }
  const path = resolve3(dataDir, "devone.secret");
  try {
    const file2 = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const s = await file2.stat();
      if (!s.isFile() || s.uid !== process.getuid?.() || s.size > 128) throw Error("Unsafe runtime key.");
      if (s.mode & 63) await file2.chmod(384);
      const value2 = (await file2.readFile("utf8")).trim();
      if (!/^[a-zA-Z0-9_-]{43}$/.test(value2)) throw Error("Invalid runtime key.");
      return value2;
    } finally {
      await file2.close();
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  const file = await open(path, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384), value = randomBytes(32).toString("base64url");
  try {
    await file.writeFile(value + "\n");
    await file.sync();
  } finally {
    await file.close();
  }
  return value;
}
async function createLocalRuntime(options) {
  const dataDir = resolve3(options.dataDir);
  await mkdir2(dataDir, { recursive: true, mode: 448 });
  const directory = await lstat(dataDir);
  if (!directory.isDirectory() || directory.isSymbolicLink() || directory.uid !== process.getuid?.()) throw Error("Runtime data must be a private owned directory.");
  if (directory.mode & 63) await chmod(dataDir, 448);
  const mediaDir = resolve3(options.mediaDir ?? dataDir + "/media");
  await mkdir2(mediaDir, { recursive: true, mode: 448 });
  const path = resolve3(dataDir, "devone.sqlite");
  if (!options.database) {
    try {
      const f = await open(path, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384);
      await f.close();
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
    const s = await lstat(path);
    if (!s.isFile() || s.isSymbolicLink() || s.uid !== process.getuid?.()) throw Error("Unsafe runtime database.");
    if (s.mode & 63) await chmod(path, 384);
  }
  const Database = DatabaseSync;
  const database = options.database ?? new Database(path);
  database.exec("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;");
  await runLocalMigrations(database);
  const secretKey = await loadSecret(dataDir, options.secretKey ?? process.env.DEVONE_SECRET_KEY);
  return createLocalServices({ ...options, dataDir, mediaDir, database, secretKey });
}

// core/installer/validation.ts
var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var usernamePattern = /^[a-z0-9][a-z0-9._-]{2,99}$/;
var slugPattern = /^[a-z0-9][a-z0-9-]{1,119}$/;
function normalizeInstallerInput(input) {
  const siteName = String(input.site?.name ?? "").trim().slice(0, 190);
  const generatedSlug = siteName.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120);
  return {
    deployment: input.deployment,
    admin: {
      username: String(input.admin?.username ?? "").trim().toLowerCase(),
      email: String(input.admin?.email ?? "").trim().toLowerCase(),
      displayName: String(input.admin?.displayName ?? "").trim().slice(0, 190),
      password: String(input.admin?.password ?? "")
    },
    site: {
      name: siteName,
      slug: String(input.site?.slug ?? generatedSlug).trim().toLowerCase(),
      url: String(input.site?.url ?? "").trim(),
      timezone: String(input.site?.timezone ?? "UTC").trim() || "UTC",
      language: String(input.site?.language ?? "en-US").trim() || "en-US"
    },
    smtp: {
      enabled: Boolean(input.smtp?.enabled),
      host: String(input.smtp?.host ?? "").trim(),
      port: Number(input.smtp?.port ?? 587),
      encryption: input.smtp?.encryption ?? "starttls",
      username: String(input.smtp?.username ?? "").trim(),
      password: String(input.smtp?.password ?? ""),
      fromEmail: String(input.smtp?.fromEmail ?? "").trim().toLowerCase(),
      fromName: String(input.smtp?.fromName ?? "").trim().slice(0, 190)
    }
  };
}
function validateInstallerInput(input) {
  if (input.deployment !== "local" && input.deployment !== "cloudflare") return "Choose Local or Cloudflare deployment.";
  if (input.site.name.length < 2) return "Site name must be at least 2 characters.";
  if (!slugPattern.test(input.site.slug)) return "Site slug must use 2-120 lowercase letters, numbers, and hyphens.";
  if (!usernamePattern.test(input.admin.username)) return "Invalid administrator username.";
  if (!emailPattern.test(input.admin.email)) return "Invalid administrator email.";
  if (input.admin.password.length < 12 || input.admin.password.length > 256) return "Administrator password must be 12-256 characters.";
  if (input.site.url) {
    try {
      const url = new URL(input.site.url);
      if (!["http:", "https:"].includes(url.protocol)) return "Site URL must use HTTP or HTTPS.";
    } catch {
      return "Invalid site URL.";
    }
  }
  const smtp = input.smtp;
  if (!smtp?.enabled) return null;
  const port = smtp.port ?? 587;
  const password = smtp.password ?? "";
  if (!smtp.host || smtp.host.length > 255) return "SMTP host is required.";
  if (!Number.isInteger(port) || port < 1 || port > 65535) return "SMTP port must be between 1 and 65535.";
  if (!["none", "starttls", "tls"].includes(smtp.encryption ?? "")) return "Invalid SMTP encryption mode.";
  if (smtp.username && password.length > 256) return "SMTP password is too long.";
  if (!emailPattern.test(smtp.fromEmail ?? "")) return "Invalid SMTP from email.";
  if (!smtp.fromName) return "SMTP from name is required.";
  return null;
}

// core/auth/service.ts
var PASSWORD_HASH_ITERATIONS = 1e4;
var PASSWORD_MIN_LENGTH = 12;
var PASSWORD_MAX_LENGTH = 256;
var enc = new TextEncoder();
var b64 = (b) => {
  let s = "";
  for (const x of b) s += String.fromCharCode(x);
  return btoa(s);
};
var unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
var eq = (a, b) => {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
};
var hash = async (s) => b64(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s))));
var token = (n = 32) => {
  const b = new Uint8Array(n);
  crypto.getRandomValues(b);
  return b64(b).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
};
var cookies = (r) => Object.fromEntries((r.headers.get("cookie") ?? "").split(";").map((x) => x.trim()).filter(Boolean).map((x) => {
  const i = x.indexOf("=");
  return i < 0 ? [x, ""] : [x.slice(0, i), decodeURIComponent(x.slice(i + 1))];
}));
var valid = (p) => p.length >= PASSWORD_MIN_LENGTH && p.length <= PASSWORD_MAX_LENGTH;
async function passwordHash(p, iterations = PASSWORD_HASH_ITERATIONS) {
  if (!Number.isSafeInteger(iterations) || iterations < 1e4 || iterations > 2e6) throw new Error("Invalid password policy.");
  if (!valid(p)) throw new Error("Invalid password length.");
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  const k = await crypto.subtle.importKey("raw", enc.encode(p), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, k, 256);
  return ["pbkdf2", "sha256", String(iterations), b64(salt), b64(new Uint8Array(bits))].join("$");
}
async function passwordVerify(p, stored) {
  const a = stored.split("$");
  if (a.length !== 5 || a[0] !== "pbkdf2" || a[1] !== "sha256") return false;
  const n = Number(a[2]);
  if (!Number.isSafeInteger(n) || n < 1e4 || n > 2e6) return false;
  try {
    const salt = unb64(a[3]), expected = unb64(a[4]), k = await crypto.subtle.importKey("raw", enc.encode(p), "PBKDF2", false, ["deriveBits"]), bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: n, hash: "SHA-256" }, k, expected.length * 8);
    return eq(new Uint8Array(bits), expected);
  } catch {
    return false;
  }
}
var future = (days) => new Date(Date.now() + days * 864e5).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "");
var setCookie = (t, age, secure) => ["devone_session=" + encodeURIComponent(t), "Path=/", "Max-Age=" + age, "HttpOnly", ...secure ? ["Secure"] : [], "SameSite=Lax"].join("; ");
var clearCookie = (secure) => "devone_session=; Path=/; Max-Age=0; HttpOnly" + (secure ? "; Secure" : "") + "; SameSite=Lax";
var DevOneAuthService = class {
  constructor(db, o = {}) {
    this.db = db;
    this.secure = o.secureCookies ?? true;
    this.days = o.sessionDays ?? 7;
    this.iterations = o.passwordHashIterations ?? PASSWORD_HASH_ITERATIONS;
    if (!Number.isSafeInteger(this.iterations) || this.iterations < 1e4 || this.iterations > 2e6) throw Error("Invalid password policy.");
  }
  db;
  secure;
  days;
  iterations;
  async session(r) {
    const c = cookies(r).devone_session;
    if (!c) return null;
    return this.db.first("SELECT id,user_id,expires_at,csrf_token_hash FROM sessions WHERE token_hash=?1 AND expires_at>datetime('now') AND revoked_at IS NULL LIMIT 1", await hash(c));
  }
  async getCurrentUser(r) {
    const s = await this.session(r);
    if (!s) return null;
    const u = await this.db.first("SELECT id,username,email,display_name,role,status FROM users WHERE id=?1 AND status='active' LIMIT 1", s.user_id);
    if (u) await this.db.run("UPDATE sessions SET last_seen_at=datetime('now') WHERE id=?1", s.id);
    return u;
  }
  async restoreSession(r) {
    const s = await this.session(r);
    if (!s) return { user: null, csrfToken: null };
    const u = await this.db.first("SELECT id,username,email,display_name,role,status FROM users WHERE id=?1 AND status='active' LIMIT 1", s.user_id);
    if (!u) return { user: null, csrfToken: null };
    const csrfToken = token();
    await this.db.run("UPDATE sessions SET csrf_token_hash=?1,last_seen_at=datetime('now') WHERE id=?2", await hash(csrfToken), s.id);
    return { user: u, csrfToken };
  }
  async audit(id, action) {
    try {
      await this.db.run("INSERT INTO activity_logs(user_id,action) VALUES(?1,?2)", id, action);
    } catch {
    }
  }
  async login(r, username, password) {
    username = username.trim().toLowerCase();
    if (!/^[a-z0-9][a-z0-9._-]{2,99}$/.test(username) || password.length < 1 || password.length > PASSWORD_MAX_LENGTH) throw new Error("Invalid credentials.");
    const u = await this.db.first("SELECT id,username,email,display_name,role,status,password_hash FROM users WHERE lower(username)=?1 LIMIT 1", username);
    if (!u || u.status !== "active" || !await passwordVerify(password, u.password_hash)) {
      await this.audit(null, "auth.login_failed");
      throw new Error("Invalid credentials.");
    }
    const parts = u.password_hash.split("$");
    if (parts.length !== 5 || Number(parts[2]) !== this.iterations) await this.db.run("UPDATE users SET password_hash=?,password_changed_at=datetime('now'),updated_at=datetime('now') WHERE id=?", await passwordHash(password, this.iterations), u.id);
    const sessionToken = token(), csrfToken = token(), id = crypto.randomUUID(), expiresAt = future(this.days);
    await this.db.run("INSERT INTO sessions(id,user_id,token_hash,csrf_token_hash,expires_at) VALUES(?,?,?,?,?)", id, u.id, await hash(sessionToken), await hash(csrfToken), expiresAt);
    await this.audit(u.id, "auth.login");
    const { password_hash: _passwordHash, ...safeUser } = u;
    return { user: safeUser, csrfToken, expiresAt, sessionCookie: setCookie(sessionToken, this.days * 86400, this.secure) };
  }
  async requireCsrf(r) {
    const s = await this.session(r);
    if (!s) throw new Error("Authentication required.");
    const supplied = unb64(await hash(r.headers.get("x-devone-csrf") ?? "")), expected = unb64(s.csrf_token_hash);
    if (!eq(supplied, expected)) throw new Error("CSRF validation failed.");
  }
  async logout(r) {
    const s = await this.session(r);
    if (!s) return clearCookie(this.secure);
    await this.requireCsrf(r);
    await this.db.run("UPDATE sessions SET revoked_at=datetime('now') WHERE id=?", s.id);
    await this.audit(s.user_id, "auth.logout");
    return clearCookie(this.secure);
  }
  async revokeUserSessions(userId) {
    await this.db.run("UPDATE sessions SET revoked_at=datetime('now') WHERE user_id=? AND revoked_at IS NULL", userId);
  }
};

// core/security/secrets.ts
var encoder = new TextEncoder();
function toBase64Url(bytes) {
  let value = "";
  for (const byte of bytes) value += String.fromCharCode(byte);
  return btoa(value).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromBase64Url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  return Uint8Array.from(atob(normalized), (char) => char.charCodeAt(0));
}
function arrayBuffer(bytes) {
  return bytes.slice().buffer;
}
async function keyFromSecret(secret) {
  const raw = fromBase64Url(secret);
  if (raw.byteLength !== 32) throw new Error("DevOne secret key must be 32 bytes.");
  return crypto.subtle.importKey("raw", arrayBuffer(raw), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptSecret(plaintext, secret) {
  if (!secret) throw new Error("Secret encryption key is not configured.");
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keyFromSecret(secret);
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: arrayBuffer(iv) }, key, encoder.encode(plaintext)));
  const packed = new Uint8Array(iv.length + ciphertext.length);
  packed.set(iv, 0);
  packed.set(ciphertext, iv.length);
  return toBase64Url(packed);
}

// core/installer/service.ts
var DEFAULT_ROLES = [
  ["administrator", "Full DevOne administration", JSON.stringify(["*"])],
  ["editor", "Manage site content", JSON.stringify(["content.*", "media.*"])],
  ["author", "Create and manage authored content", JSON.stringify(["content.create", "content.read", "content.update", "media.create"])],
  ["subscriber", "Basic authenticated account", JSON.stringify([])],
  ["site_admin", "Manage an assigned site", JSON.stringify(["site.*", "content.*", "media.*"])]
];
var DevOneInstaller = class {
  constructor(services) {
    this.services = services;
  }
  services;
  async status() {
    const installed = await this.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = 'installation_complete' LIMIT 1"
    );
    const deployment = await this.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = 'deployment_mode' LIMIT 1"
    );
    const site = await this.services.db.first(
      "SELECT site_name, primary_domain FROM sites ORDER BY id ASC LIMIT 1"
    );
    return {
      installed: installed?.setting_value === "1",
      deployment: deployment?.setting_value === "local" || deployment?.setting_value === "cloudflare" ? deployment.setting_value : null,
      runtime: String(this.services.config.runtime ?? "provider-independent"),
      siteName: site?.site_name ?? null,
      siteUrl: site?.primary_domain ?? null
    };
  }
  async install(rawInput) {
    const input = normalizeInstallerInput(rawInput);
    const validationError = validateInstallerInput(input);
    if (validationError) throw new Error(validationError);
    const current = await this.status();
    if (current.installed) throw new Error("DevOne is already installed.");
    const existingUser = await this.services.db.first("SELECT id FROM users LIMIT 1");
    if (existingUser) throw new Error("An administrator already exists.");
    const hashedPassword = await passwordHash(input.admin.password, Number(this.services.config.password_hash_iterations ?? 1e4));
    let smtpPasswordEncrypted = "";
    if (input.smtp?.enabled && input.smtp.password) {
      const secret = String(this.services.config.secret_key ?? "");
      if (!secret) throw new Error("SMTP secrets cannot be stored because the runtime secret key is not configured.");
      smtpPasswordEncrypted = await encryptSecret(input.smtp.password, secret);
    }
    const primaryDomain = input.site.url ? new URL(input.site.url).hostname : "";
    const smtp = input.smtp ?? { enabled: false, host: "", port: 587, encryption: "starttls", username: "", password: "", fromEmail: input.admin.email, fromName: input.site.name };
    const settings = [
      ["deployment_mode", input.deployment],
      ["site_name", input.site.name],
      ["site_title", input.site.name],
      ["site_tagline", "Build. Manage. Evolve."],
      ["site_url", input.site.url ?? ""],
      ["timezone", input.site.timezone ?? "UTC"],
      ["language", input.site.language ?? "en-US"],
      ["cms_version", "2.0.0-alpha.4"],
      ["site_theme", "devone-glass"],
      ["smtp_enabled", smtp.enabled ? "1" : "0"],
      ["smtp_host", smtp.host ?? ""],
      ["smtp_port", String(smtp.port ?? 587)],
      ["smtp_encryption", smtp.encryption ?? "starttls"],
      ["smtp_username", smtp.username ?? ""],
      ["smtp_password_encrypted", smtpPasswordEncrypted],
      ["smtp_from_email", smtp.fromEmail ?? input.admin.email],
      ["smtp_from_name", smtp.fromName ?? input.site.name],
      ["installation_complete", "1"]
    ];
    const statements = DEFAULT_ROLES.map(([name, description, permissions]) => ({
      sql: "INSERT OR IGNORE INTO roles (name, description, permissions) VALUES (?1, ?2, ?3)",
      params: [name, description, permissions]
    }));
    statements.push(
      {
        sql: "INSERT INTO users (username, password_hash, email, display_name, role, status, password_changed_at) VALUES (?1, ?2, ?3, ?4, 'administrator', 'active', CURRENT_TIMESTAMP)",
        params: [input.admin.username, hashedPassword, input.admin.email, input.admin.displayName || input.admin.username]
      },
      {
        sql: "INSERT INTO sites (site_name, site_slug, primary_domain, owner_user_id, admin_username, admin_email, status) VALUES (?1, ?2, ?3, (SELECT id FROM users WHERE username = ?4 LIMIT 1), ?4, ?5, 'active')",
        params: [input.site.name, input.site.slug, primaryDomain, input.admin.username, input.admin.email]
      },
      {
        sql: "INSERT INTO site_users (site_id, user_id, role, status) VALUES ((SELECT id FROM sites WHERE site_slug = ?1 LIMIT 1), (SELECT id FROM users WHERE username = ?2 LIMIT 1), 'site_admin', 'active')",
        params: [input.site.slug, input.admin.username]
      },
      {
        sql: "INSERT INTO pages (site_id, slug, title, content, template, show_title, status, author_id) VALUES ((SELECT id FROM sites WHERE site_slug = ?1 LIMIT 1), 'home', ?2, ?3, 'default', 0, 'published', (SELECT id FROM users WHERE username = ?4 LIMIT 1))",
        params: [input.site.slug, input.site.name, "<h1>Welcome to DevOne CMS 2.0</h1><p>Performance, Security, Design.</p>", input.admin.username]
      }
    );
    for (const [key, value] of settings) {
      statements.push({
        sql: "INSERT INTO settings (setting_key, setting_value) VALUES (?1, ?2) ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value",
        params: [key, value]
      });
    }
    await this.services.db.batch(statements);
    const site = await this.services.db.first(
      "SELECT id, owner_user_id FROM sites WHERE site_slug = ?1 LIMIT 1",
      input.site.slug
    );
    const user = await this.services.db.first(
      "SELECT id FROM users WHERE username = ?1 LIMIT 1",
      input.admin.username
    );
    if (!site?.id || !user?.id) throw new Error("Installation completed without required records.");
    return {
      siteId: site.id,
      userId: user.id,
      deployment: input.deployment,
      smtpConfigured: Boolean(input.smtp?.enabled)
    };
  }
};

// runtime/managed-bootstrap.ts
process.umask(63);
try {
  let raw = "";
  for await (const b2 of process.stdin) {
    raw += b2;
    if (Buffer.byteLength(raw) > 4096) throw Error();
  }
  const b = JSON.parse(raw);
  if (Object.keys(b).some((k) => !["title", "email", "password", "url"].includes(k)) || !/^[a-f0-9]{64}$/.test(b.password) || !process.env.DEVONE_DATA_DIR) throw Error();
  const url = new URL(b.url);
  if (url.protocol !== "https:" || url.origin !== b.url) throw Error();
  const services = await createLocalRuntime({ dataDir: process.env.DEVONE_DATA_DIR, environment: "production" });
  const installer = new DevOneInstaller(services);
  await installer.install({ deployment: "local", admin: { username: "devone_admin", email: b.email, displayName: "Administrator", password: b.password }, site: { name: b.title, slug: "main", url: b.url }, smtp: { enabled: false } });
  const auth = new DevOneAuthService(services.db, { secureCookies: true, passwordHashIterations: 6e5 });
  await auth.login(new Request(b.url), "devone_admin", b.password);
  await services.db.run("DELETE FROM sessions");
  process.stdout.write(JSON.stringify({ ok: true, version: "2.0.0-alpha.4" }));
} catch {
  process.stderr.write("cms_bootstrap_requires_inspection\n");
  process.exitCode = 1;
}
