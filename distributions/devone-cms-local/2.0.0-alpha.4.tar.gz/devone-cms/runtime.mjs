var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// core/auth/service.ts
var service_exports = {};
__export(service_exports, {
  DevOneAuthService: () => DevOneAuthService,
  PASSWORD_HASH_ITERATIONS: () => PASSWORD_HASH_ITERATIONS,
  PASSWORD_MAX_LENGTH: () => PASSWORD_MAX_LENGTH,
  PASSWORD_MIN_LENGTH: () => PASSWORD_MIN_LENGTH,
  authErrorStatus: () => authErrorStatus,
  passwordHash: () => passwordHash
});
async function passwordHash(p, iterations = PASSWORD_HASH_ITERATIONS) {
  if (!Number.isSafeInteger(iterations) || iterations < 1e4 || iterations > 2e6) throw new Error("Invalid password policy.");
  if (!valid(p)) throw new Error("Invalid password length.");
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  const k = await crypto.subtle.importKey("raw", enc.encode(p), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations, hash: "SHA-256" }, k, 256);
  return ["pbkdf2", "sha256", String(iterations), b64(salt), b64(new Uint8Array(bits))].join("$");
}
async function passwordVerify(p, stored) {
  const a = stored.split("$");
  if (a.length !== 5 || a[0] !== "pbkdf2" || a[1] !== "sha256") return false;
  const n = Number(a[2]);
  if (!Number.isSafeInteger(n) || n < 1e4 || n > 2e6) return false;
  try {
    const salt = unb64(a[3]), expected = unb64(a[4]), k = await crypto.subtle.importKey("raw", enc.encode(p), "PBKDF2", false, ["deriveBits"]), bits = await crypto.subtle.deriveBits({ name: "PBKDF2", salt, iterations: n, hash: "SHA-256" }, k, expected.length * 8);
    return eq(new Uint8Array(bits), expected);
  } catch {
    return false;
  }
}
var PASSWORD_HASH_ITERATIONS, PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH, enc, b64, unb64, eq, hash, token, cookies, valid, future, setCookie, clearCookie, DevOneAuthService, authErrorStatus;
var init_service = __esm({
  "core/auth/service.ts"() {
    "use strict";
    PASSWORD_HASH_ITERATIONS = 1e4;
    PASSWORD_MIN_LENGTH = 12;
    PASSWORD_MAX_LENGTH = 256;
    enc = new TextEncoder();
    b64 = (b) => {
      let s = "";
      for (const x of b) s += String.fromCharCode(x);
      return btoa(s);
    };
    unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
    eq = (a, b) => {
      if (a.length !== b.length) return false;
      let d = 0;
      for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
      return d === 0;
    };
    hash = async (s) => b64(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s))));
    token = (n = 32) => {
      const b = new Uint8Array(n);
      crypto.getRandomValues(b);
      return b64(b).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
    };
    cookies = (r) => Object.fromEntries((r.headers.get("cookie") ?? "").split(";").map((x) => x.trim()).filter(Boolean).map((x) => {
      const i = x.indexOf("=");
      return i < 0 ? [x, ""] : [x.slice(0, i), decodeURIComponent(x.slice(i + 1))];
    }));
    valid = (p) => p.length >= PASSWORD_MIN_LENGTH && p.length <= PASSWORD_MAX_LENGTH;
    future = (days) => new Date(Date.now() + days * 864e5).toISOString().replace("T", " ").replace(/\.\d{3}Z$/, "");
    setCookie = (t, age, secure) => ["devone_session=" + encodeURIComponent(t), "Path=/", "Max-Age=" + age, "HttpOnly", ...secure ? ["Secure"] : [], "SameSite=Lax"].join("; ");
    clearCookie = (secure) => "devone_session=; Path=/; Max-Age=0; HttpOnly" + (secure ? "; Secure" : "") + "; SameSite=Lax";
    DevOneAuthService = class {
      constructor(db, o = {}) {
        this.db = db;
        this.secure = o.secureCookies ?? true;
        this.days = o.sessionDays ?? 7;
        this.iterations = o.passwordHashIterations ?? PASSWORD_HASH_ITERATIONS;
        if (!Number.isSafeInteger(this.iterations) || this.iterations < 1e4 || this.iterations > 2e6) throw Error("Invalid password policy.");
      }
      db;
      secure;
      days;
      iterations;
      async session(r) {
        const c = cookies(r).devone_session;
        if (!c) return null;
        return this.db.first("SELECT id,user_id,expires_at,csrf_token_hash FROM sessions WHERE token_hash=?1 AND expires_at>datetime('now') AND revoked_at IS NULL LIMIT 1", await hash(c));
      }
      async getCurrentUser(r) {
        const s = await this.session(r);
        if (!s) return null;
        const u = await this.db.first("SELECT id,username,email,display_name,role,status FROM users WHERE id=?1 AND status='active' LIMIT 1", s.user_id);
        if (u) await this.db.run("UPDATE sessions SET last_seen_at=datetime('now') WHERE id=?1", s.id);
        return u;
      }
      async restoreSession(r) {
        const s = await this.session(r);
        if (!s) return { user: null, csrfToken: null };
        const u = await this.db.first("SELECT id,username,email,display_name,role,status FROM users WHERE id=?1 AND status='active' LIMIT 1", s.user_id);
        if (!u) return { user: null, csrfToken: null };
        const csrfToken = token();
        await this.db.run("UPDATE sessions SET csrf_token_hash=?1,last_seen_at=datetime('now') WHERE id=?2", await hash(csrfToken), s.id);
        return { user: u, csrfToken };
      }
      async audit(id, action) {
        try {
          await this.db.run("INSERT INTO activity_logs(user_id,action) VALUES(?1,?2)", id, action);
        } catch {
        }
      }
      async login(r, username, password) {
        username = username.trim().toLowerCase();
        if (!/^[a-z0-9][a-z0-9._-]{2,99}$/.test(username) || password.length < 1 || password.length > PASSWORD_MAX_LENGTH) throw new Error("Invalid credentials.");
        const u = await this.db.first("SELECT id,username,email,display_name,role,status,password_hash FROM users WHERE lower(username)=?1 LIMIT 1", username);
        if (!u || u.status !== "active" || !await passwordVerify(password, u.password_hash)) {
          await this.audit(null, "auth.login_failed");
          throw new Error("Invalid credentials.");
        }
        const parts = u.password_hash.split("$");
        if (parts.length !== 5 || Number(parts[2]) !== this.iterations) await this.db.run("UPDATE users SET password_hash=?,password_changed_at=datetime('now'),updated_at=datetime('now') WHERE id=?", await passwordHash(password, this.iterations), u.id);
        const sessionToken = token(), csrfToken = token(), id = crypto.randomUUID(), expiresAt = future(this.days);
        await this.db.run("INSERT INTO sessions(id,user_id,token_hash,csrf_token_hash,expires_at) VALUES(?,?,?,?,?)", id, u.id, await hash(sessionToken), await hash(csrfToken), expiresAt);
        await this.audit(u.id, "auth.login");
        const { password_hash: _passwordHash, ...safeUser } = u;
        return { user: safeUser, csrfToken, expiresAt, sessionCookie: setCookie(sessionToken, this.days * 86400, this.secure) };
      }
      async requireCsrf(r) {
        const s = await this.session(r);
        if (!s) throw new Error("Authentication required.");
        const supplied = unb64(await hash(r.headers.get("x-devone-csrf") ?? "")), expected = unb64(s.csrf_token_hash);
        if (!eq(supplied, expected)) throw new Error("CSRF validation failed.");
      }
      async logout(r) {
        const s = await this.session(r);
        if (!s) return clearCookie(this.secure);
        await this.requireCsrf(r);
        await this.db.run("UPDATE sessions SET revoked_at=datetime('now') WHERE id=?", s.id);
        await this.audit(s.user_id, "auth.logout");
        return clearCookie(this.secure);
      }
      async revokeUserSessions(userId) {
        await this.db.run("UPDATE sessions SET revoked_at=datetime('now') WHERE user_id=? AND revoked_at IS NULL", userId);
      }
    };
    authErrorStatus = (e) => {
      const x = e;
      return x.message === "Authentication required." || x.message === "Invalid credentials." ? 401 : x.message === "CSRF validation failed." ? 403 : 400;
    };
  }
});

// runtime/local-server.ts
import { open as open2 } from "node:fs/promises";
import { constants as constants2 } from "node:fs";
import { resolve as resolve4, extname } from "node:path";
import { fileURLToPath as fileURLToPath2 } from "node:url";
import { createServer } from "node:http";

// adapters/local/runtime.ts
import { constants } from "node:fs";
import { mkdir as mkdir2, lstat, open, chmod } from "node:fs/promises";
import { resolve as resolve3 } from "node:path";
import { randomBytes } from "node:crypto";
import { DatabaseSync } from "node:sqlite";

// adapters/local/providers.ts
import { mkdir, readFile, writeFile, unlink, stat, access } from "node:fs/promises";
import { dirname, resolve, relative, isAbsolute, sep } from "node:path";
var LocalDatabase = class {
  constructor(db) {
    this.db = db;
  }
  db;
  async first(sql, ...params) {
    return this.db.prepare(sql).get(...params) ?? null;
  }
  async all(sql, ...params) {
    return this.db.prepare(sql).all(...params);
  }
  async run(sql, ...params) {
    const r = this.db.prepare(sql).run(...params);
    return { changes: Number(r.changes), lastInsertId: Number(r.lastInsertRowid) };
  }
  async batch(statements) {
    this.db.exec("BEGIN IMMEDIATE;");
    try {
      for (const s of statements) this.db.prepare(s.sql).run(...s.params ?? []);
      this.db.exec("COMMIT;");
    } catch (error) {
      try {
        this.db.exec("ROLLBACK;");
      } catch {
      }
      throw error;
    }
  }
};
var LocalCache = class {
  values = /* @__PURE__ */ new Map();
  async get(key) {
    const hit = this.values.get(key);
    if (!hit) return null;
    if (hit.expires !== null && hit.expires <= Date.now()) {
      this.values.delete(key);
      return null;
    }
    return hit.value;
  }
  async set(key, value, ttlSeconds) {
    this.values.set(key, { value, expires: ttlSeconds && ttlSeconds > 0 ? Date.now() + ttlSeconds * 1e3 : null });
  }
  async delete(key) {
    this.values.delete(key);
  }
};
var LocalMedia = class {
  root;
  constructor(root) {
    this.root = resolve(root);
  }
  safe(key) {
    const normalized = key.replace(/\\/g, "/").replace(/^\/+/, "");
    const path = resolve(this.root, normalized);
    const rel = relative(this.root, path);
    if (isAbsolute(rel) || rel.startsWith(".." + sep) || rel === "..") throw new Error("Invalid media key.");
    return path;
  }
  async put(key, body2, options = {}) {
    const path = this.safe(key);
    await mkdir(dirname(path), { recursive: true });
    let data;
    if (typeof body2 === "string") data = new TextEncoder().encode(body2);
    else if (body2 instanceof Uint8Array) data = body2;
    else if (body2 instanceof ArrayBuffer) data = new Uint8Array(body2);
    else data = new Uint8Array(await new Response(body2).arrayBuffer());
    await writeFile(path, data);
    const info = await stat(path);
    return { key, contentType: options.contentType ?? "", size: info.size, metadata: options.metadata };
  }
  async get(key) {
    try {
      return new Response(await readFile(this.safe(key)));
    } catch (e) {
      if (e.code === "ENOENT") return null;
      throw e;
    }
  }
  async delete(key) {
    try {
      await unlink(this.safe(key));
    } catch (e) {
      if (e.code !== "ENOENT") throw e;
    }
  }
  async exists(key) {
    try {
      await access(this.safe(key));
      return true;
    } catch {
      return false;
    }
  }
};
function createLocalServices(options) {
  return {
    db: new LocalDatabase(options.database),
    cache: new LocalCache(),
    media: new LocalMedia(options.mediaDir),
    config: {
      runtime: "local",
      password_hash_iterations: options.environment === "production" ? 6e5 : 1e4,
      environment: options.environment ?? "development",
      media_dir: options.mediaDir,
      secret_key: options.secretKey ?? ""
    }
  };
}

// adapters/local/migrations.ts
import { readdir, readFile as readFile2 } from "node:fs/promises";
import { resolve as resolve2 } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
async function runLocalMigrations(db, migrationsDir = process.env.DEVONE_MIGRATIONS_DIR ? pathToFileURL(resolve2(process.env.DEVONE_MIGRATIONS_DIR) + "/") : new URL("../../migrations/", import.meta.url)) {
  db.exec("CREATE TABLE IF NOT EXISTS devone_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);");
  const dirPath = resolve2(fileURLToPath(migrationsDir));
  const names = (await readdir(dirPath)).filter((n) => /^\d+_.+\.sql$/.test(n)).sort();
  for (const name of names) {
    const exists = db.prepare("SELECT name FROM devone_migrations WHERE name=?1").get(name);
    if (exists) continue;
    const sql = await readFile2(resolve2(dirPath, name), "utf8");
    db.exec("BEGIN IMMEDIATE;");
    try {
      db.exec(sql);
      db.prepare("INSERT INTO devone_migrations(name) VALUES(?1)").run(name);
      db.exec("COMMIT;");
    } catch (error) {
      try {
        db.exec("ROLLBACK;");
      } catch {
      }
      ;
      throw new Error("Migration failed: " + name, { cause: error });
    }
  }
}

// adapters/local/runtime.ts
async function loadSecret(dataDir, supplied) {
  if (supplied) {
    if (!/^[a-zA-Z0-9_-]{43}$/.test(supplied)) throw Error("Invalid runtime key.");
    return supplied;
  }
  const path = resolve3(dataDir, "devone.secret");
  try {
    const file2 = await open(path, constants.O_RDONLY | constants.O_NOFOLLOW);
    try {
      const s = await file2.stat();
      if (!s.isFile() || s.uid !== process.getuid?.() || s.size > 128) throw Error("Unsafe runtime key.");
      if (s.mode & 63) await file2.chmod(384);
      const value2 = (await file2.readFile("utf8")).trim();
      if (!/^[a-zA-Z0-9_-]{43}$/.test(value2)) throw Error("Invalid runtime key.");
      return value2;
    } finally {
      await file2.close();
    }
  } catch (e) {
    if (e.code !== "ENOENT") throw e;
  }
  const file = await open(path, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384), value = randomBytes(32).toString("base64url");
  try {
    await file.writeFile(value + "\n");
    await file.sync();
  } finally {
    await file.close();
  }
  return value;
}
async function createLocalRuntime(options) {
  const dataDir = resolve3(options.dataDir);
  await mkdir2(dataDir, { recursive: true, mode: 448 });
  const directory = await lstat(dataDir);
  if (!directory.isDirectory() || directory.isSymbolicLink() || directory.uid !== process.getuid?.()) throw Error("Runtime data must be a private owned directory.");
  if (directory.mode & 63) await chmod(dataDir, 448);
  const mediaDir = resolve3(options.mediaDir ?? dataDir + "/media");
  await mkdir2(mediaDir, { recursive: true, mode: 448 });
  const path = resolve3(dataDir, "devone.sqlite");
  if (!options.database) {
    try {
      const f = await open(path, constants.O_WRONLY | constants.O_CREAT | constants.O_EXCL | constants.O_NOFOLLOW, 384);
      await f.close();
    } catch (e) {
      if (e.code !== "EEXIST") throw e;
    }
    const s = await lstat(path);
    if (!s.isFile() || s.isSymbolicLink() || s.uid !== process.getuid?.()) throw Error("Unsafe runtime database.");
    if (s.mode & 63) await chmod(path, 384);
  }
  const Database = DatabaseSync;
  const database = options.database ?? new Database(path);
  database.exec("PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;");
  await runLocalMigrations(database);
  const secretKey = await loadSecret(dataDir, options.secretKey ?? process.env.DEVONE_SECRET_KEY);
  return createLocalServices({ ...options, dataDir, mediaDir, database, secretKey });
}

// core/api/router.ts
var METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"];
var STATE_CHANGING_METHODS = /* @__PURE__ */ new Set(["POST", "PUT", "PATCH", "DELETE"]);
var DEFAULT_MAX_BODY_BYTES = 1024 * 1024;
function normalizePath(path) {
  const normalized = path.replace(/\/+$/, "");
  return normalized || "/";
}
function compilePath(path) {
  const names = [];
  const pattern = normalizePath(path).split("/").map((segment) => {
    if (segment.startsWith(":")) {
      names.push(segment.slice(1));
      return "([^/]+)";
    }
    if (segment === "*") {
      names.push("wildcard");
      return "(.*)";
    }
    return segment.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
  }).join("/");
  return { regex: new RegExp("^" + pattern + "/?$"), names };
}
var ApiRouter = class {
  routes = [];
  register(route) {
    const methods = Array.isArray(route.method) ? route.method : [route.method];
    for (const method of methods) {
      if (!METHODS.includes(method)) throw new Error("Unsupported API method: " + method);
    }
    const compiled = compilePath(route.path);
    this.routes.push({ ...route, methods, ...compiled });
    return this;
  }
  get(path, handler, options = {}) {
    return this.register({ ...options, method: "GET", path, handler });
  }
  post(path, handler, options = {}) {
    return this.register({ ...options, method: "POST", path, handler });
  }
  put(path, handler, options = {}) {
    return this.register({ ...options, method: "PUT", path, handler });
  }
  patch(path, handler, options = {}) {
    return this.register({ ...options, method: "PATCH", path, handler });
  }
  delete(path, handler, options = {}) {
    return this.register({ ...options, method: "DELETE", path, handler });
  }
  allowedMethods(path) {
    const normalized = normalizePath(path);
    const methods = /* @__PURE__ */ new Set();
    for (const route of this.routes) if (route.regex.test(normalized)) for (const method of route.methods) methods.add(method);
    return [...methods];
  }
  match(method, path) {
    const normalized = normalizePath(path);
    for (const route of this.routes) {
      if (!route.methods.includes(method)) continue;
      const match = route.regex.exec(normalized);
      if (!match) continue;
      const params = {};
      route.names.forEach((name, index) => {
        params[name] = decodeURIComponent(match[index + 1] ?? "");
      });
      return { route, params };
    }
    return null;
  }
};
function ok(body2, status = 200, headers) {
  return { status, body: body2, headers };
}
function fail(error, status = 400, code, details) {
  return {
    status,
    body: {
      ok: false,
      error,
      ...code ? { code } : {},
      ...details === void 0 ? {} : { details }
    }
  };
}
function hasJsonContentType(request) {
  const contentType = request.headers.get("content-type") ?? "";
  return contentType.toLowerCase().split(";")[0].trim() === "application/json";
}
async function parseBody(request, maxBodyBytes) {
  const contentLength = request.headers.get("content-length");
  if (contentLength && Number.isFinite(Number(contentLength)) && Number(contentLength) > maxBodyBytes) {
    return { error: fail("Request body is too large.", 413, "body_too_large") };
  }
  if (!request.body) return { body: void 0 };
  const contentType = request.headers.get("content-type") ?? "";
  if (!hasJsonContentType(request)) {
    return { error: fail("State-changing API requests must use application/json.", 415, "unsupported_media_type") };
  }
  const body2 = await request.arrayBuffer();
  if (body2.byteLength > maxBodyBytes) {
    return { error: fail("Request body is too large.", 413, "body_too_large") };
  }
  if (body2.byteLength === 0) return { error: fail("Request body is required.", 400, "empty_body") };
  try {
    return { body: JSON.parse(new TextDecoder().decode(body2)) };
  } catch {
    return { error: fail("Malformed JSON request body.", 400, "invalid_json") };
  }
}
var DevOneApi = class {
  constructor(router, options) {
    this.router = router;
    this.options = options;
  }
  router;
  options;
  async handle(request) {
    const url = new URL(request.url);
    const method = request.method;
    if (!METHODS.includes(method)) return this.json(fail("Method not allowed.", 405, "method_not_allowed"), { "allow": METHODS.join(", ") });
    const matched = this.router.match(method, url.pathname);
    if (!matched) {
      const allowed = this.router.allowedMethods(url.pathname);
      if (allowed.length) {
        return this.json(fail("Method not allowed.", 405, "method_not_allowed"), { allow: allowed.join(", ") });
      }
      return this.json(fail("API route not found.", 404, "route_not_found"));
    }
    const route = matched.route;
    const isStateChanging = STATE_CHANGING_METHODS.has(method);
    const bodyResult = isStateChanging ? await parseBody(request, this.options.maxBodyBytes ?? DEFAULT_MAX_BODY_BYTES) : { body: void 0 };
    if (bodyResult.error) return this.json(bodyResult.error);
    const body2 = bodyResult.body;
    let user = null;
    try {
      user = this.options.authenticate ? await this.options.authenticate(request) : null;
    } catch {
      return this.json(fail("Authentication could not be completed.", 500, "authentication_error"));
    }
    const siteId = this.options.resolveSite ? await this.options.resolveSite(request, user) : null;
    if (!route.public && !user) {
      return this.json(fail("Authentication required.", 401, "authentication_required"));
    }
    if (route.csrf !== false && isStateChanging && user && this.options.validateCsrf) {
      const valid2 = await this.options.validateCsrf(request, user);
      if (!valid2) return this.json(fail("CSRF validation failed.", 403, "csrf_failed"));
    }
    if (route.permission && this.options.authorize) {
      const allowed = await this.options.authorize(user, route.permission, siteId);
      if (!allowed) return this.json(fail("Permission denied.", 403, "permission_denied"));
    }
    const coreRequest = {
      method,
      path: url.pathname,
      headers: request.headers,
      query: url.searchParams,
      params: matched.params,
      body: body2,
      raw: request
    };
    const context = {
      user,
      siteId,
      services: this.options.services,
      body: body2
    };
    try {
      return this.json(await route.handler(coreRequest, context));
    } catch (error) {
      console.error("DevOne Core API error", error);
      return this.json(fail("Internal server error.", 500, "internal_error"));
    }
  }
  json(result, extraHeaders = {}) {
    const headers = new Headers(result.headers);
    for (const [key, value] of new Headers(extraHeaders)) headers.set(key, value);
    headers.set("content-type", "application/json; charset=utf-8");
    headers.set("cache-control", "no-store");
    return new Response(JSON.stringify(result.body ?? null), { status: result.status, headers });
  }
};

// core/license/service.ts
var DEFAULT_SINGLE_SITE_LIMIT = 1;
var DevOneLicense = class {
  constructor(provider) {
    this.provider = provider;
  }
  provider;
  async get() {
    return this.provider.getEntitlement();
  }
  async isFeatureEnabled(feature) {
    const entitlement = await this.get();
    return Boolean(entitlement?.features.includes(feature));
  }
  async canCreateSite(currentSiteCount) {
    const entitlement = await this.get();
    if (!entitlement) return currentSiteCount < DEFAULT_SINGLE_SITE_LIMIT;
    if (entitlement.expiresAt && Date.parse(entitlement.expiresAt) <= Date.now()) {
      return currentSiteCount < DEFAULT_SINGLE_SITE_LIMIT;
    }
    if (entitlement.edition !== "network") {
      return currentSiteCount < DEFAULT_SINGLE_SITE_LIMIT;
    }
    if (entitlement.maxSites === null) return true;
    return currentSiteCount < Math.max(1, entitlement.maxSites);
  }
  async requireFeature(feature) {
    if (!await this.isFeatureEnabled(feature)) {
      throw new Error("This DevOne feature requires a valid license entitlement.");
    }
  }
};

// core/license/offline.ts
var OfflineLicenseProvider = class {
  async getEntitlement() {
    return null;
  }
  async activate(_licenseKey) {
    throw new Error("License activation is unavailable until a license provider is configured.");
  }
  async deactivate() {
  }
};

// core/sites/service.ts
var DevOneSiteService = class {
  constructor(db, license) {
    this.db = db;
    this.license = license;
  }
  db;
  license;
  async count() {
    const row = await this.db.first("SELECT COUNT(*) AS count FROM sites");
    return Number(row?.count ?? 0);
  }
  async canCreate() {
    return this.license.canCreateSite(await this.count());
  }
  async create(input) {
    const current = await this.count();
    if (!await this.license.canCreateSite(current)) {
      throw new Error("This installation is limited to one site. A valid Network license is required for additional sites.");
    }
    const result = await this.db.run(
      "INSERT INTO sites (site_name, site_slug, primary_domain, owner_user_id, admin_username, status) VALUES (?1, ?2, ?3, ?4, '', 'active')",
      input.siteName,
      input.siteSlug,
      input.primaryDomain ?? "",
      input.ownerUserId
    );
    if (!result.lastInsertId) throw new Error("Site could not be created.");
    return result.lastInsertId;
  }
};

// core/installer/validation.ts
var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var usernamePattern = /^[a-z0-9][a-z0-9._-]{2,99}$/;
var slugPattern = /^[a-z0-9][a-z0-9-]{1,119}$/;
function normalizeInstallerInput(input) {
  const siteName = String(input.site?.name ?? "").trim().slice(0, 190);
  const generatedSlug = siteName.toLowerCase().replace(/[^a-z0-9-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 120);
  return {
    deployment: input.deployment,
    admin: {
      username: String(input.admin?.username ?? "").trim().toLowerCase(),
      email: String(input.admin?.email ?? "").trim().toLowerCase(),
      displayName: String(input.admin?.displayName ?? "").trim().slice(0, 190),
      password: String(input.admin?.password ?? "")
    },
    site: {
      name: siteName,
      slug: String(input.site?.slug ?? generatedSlug).trim().toLowerCase(),
      url: String(input.site?.url ?? "").trim(),
      timezone: String(input.site?.timezone ?? "UTC").trim() || "UTC",
      language: String(input.site?.language ?? "en-US").trim() || "en-US"
    },
    smtp: {
      enabled: Boolean(input.smtp?.enabled),
      host: String(input.smtp?.host ?? "").trim(),
      port: Number(input.smtp?.port ?? 587),
      encryption: input.smtp?.encryption ?? "starttls",
      username: String(input.smtp?.username ?? "").trim(),
      password: String(input.smtp?.password ?? ""),
      fromEmail: String(input.smtp?.fromEmail ?? "").trim().toLowerCase(),
      fromName: String(input.smtp?.fromName ?? "").trim().slice(0, 190)
    }
  };
}
function validateInstallerInput(input) {
  if (input.deployment !== "local" && input.deployment !== "cloudflare") return "Choose Local or Cloudflare deployment.";
  if (input.site.name.length < 2) return "Site name must be at least 2 characters.";
  if (!slugPattern.test(input.site.slug)) return "Site slug must use 2-120 lowercase letters, numbers, and hyphens.";
  if (!usernamePattern.test(input.admin.username)) return "Invalid administrator username.";
  if (!emailPattern.test(input.admin.email)) return "Invalid administrator email.";
  if (input.admin.password.length < 12 || input.admin.password.length > 256) return "Administrator password must be 12-256 characters.";
  if (input.site.url) {
    try {
      const url = new URL(input.site.url);
      if (!["http:", "https:"].includes(url.protocol)) return "Site URL must use HTTP or HTTPS.";
    } catch {
      return "Invalid site URL.";
    }
  }
  const smtp = input.smtp;
  if (!smtp?.enabled) return null;
  const port2 = smtp.port ?? 587;
  const password = smtp.password ?? "";
  if (!smtp.host || smtp.host.length > 255) return "SMTP host is required.";
  if (!Number.isInteger(port2) || port2 < 1 || port2 > 65535) return "SMTP port must be between 1 and 65535.";
  if (!["none", "starttls", "tls"].includes(smtp.encryption ?? "")) return "Invalid SMTP encryption mode.";
  if (smtp.username && password.length > 256) return "SMTP password is too long.";
  if (!emailPattern.test(smtp.fromEmail ?? "")) return "Invalid SMTP from email.";
  if (!smtp.fromName) return "SMTP from name is required.";
  return null;
}

// core/installer/service.ts
init_service();

// core/security/secrets.ts
var encoder = new TextEncoder();
function toBase64Url(bytes) {
  let value = "";
  for (const byte of bytes) value += String.fromCharCode(byte);
  return btoa(value).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}
function fromBase64Url(value) {
  const normalized = value.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat((4 - value.length % 4) % 4);
  return Uint8Array.from(atob(normalized), (char) => char.charCodeAt(0));
}
function arrayBuffer(bytes) {
  return bytes.slice().buffer;
}
async function keyFromSecret(secret) {
  const raw = fromBase64Url(secret);
  if (raw.byteLength !== 32) throw new Error("DevOne secret key must be 32 bytes.");
  return crypto.subtle.importKey("raw", arrayBuffer(raw), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
async function encryptSecret(plaintext, secret) {
  if (!secret) throw new Error("Secret encryption key is not configured.");
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keyFromSecret(secret);
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: arrayBuffer(iv) }, key, encoder.encode(plaintext)));
  const packed = new Uint8Array(iv.length + ciphertext.length);
  packed.set(iv, 0);
  packed.set(ciphertext, iv.length);
  return toBase64Url(packed);
}
async function decryptSecret(value, secret) {
  if (!secret) throw new Error("Secret encryption key is not configured.");
  const packed = fromBase64Url(value);
  if (packed.byteLength < 13) throw new Error("Invalid encrypted secret.");
  const key = await keyFromSecret(secret);
  const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv: arrayBuffer(packed.slice(0, 12)) }, key, arrayBuffer(packed.slice(12)));
  return new TextDecoder().decode(plaintext);
}

// core/installer/service.ts
var DEFAULT_ROLES = [
  ["administrator", "Full DevOne administration", JSON.stringify(["*"])],
  ["editor", "Manage site content", JSON.stringify(["content.*", "media.*"])],
  ["author", "Create and manage authored content", JSON.stringify(["content.create", "content.read", "content.update", "media.create"])],
  ["subscriber", "Basic authenticated account", JSON.stringify([])],
  ["site_admin", "Manage an assigned site", JSON.stringify(["site.*", "content.*", "media.*"])]
];
var DevOneInstaller = class {
  constructor(services2) {
    this.services = services2;
  }
  services;
  async status() {
    const installed = await this.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = 'installation_complete' LIMIT 1"
    );
    const deployment = await this.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = 'deployment_mode' LIMIT 1"
    );
    const site = await this.services.db.first(
      "SELECT site_name, primary_domain FROM sites ORDER BY id ASC LIMIT 1"
    );
    return {
      installed: installed?.setting_value === "1",
      deployment: deployment?.setting_value === "local" || deployment?.setting_value === "cloudflare" ? deployment.setting_value : null,
      runtime: String(this.services.config.runtime ?? "provider-independent"),
      siteName: site?.site_name ?? null,
      siteUrl: site?.primary_domain ?? null
    };
  }
  async install(rawInput) {
    const input = normalizeInstallerInput(rawInput);
    const validationError = validateInstallerInput(input);
    if (validationError) throw new Error(validationError);
    const current = await this.status();
    if (current.installed) throw new Error("DevOne is already installed.");
    const existingUser = await this.services.db.first("SELECT id FROM users LIMIT 1");
    if (existingUser) throw new Error("An administrator already exists.");
    const hashedPassword = await passwordHash(input.admin.password, Number(this.services.config.password_hash_iterations ?? 1e4));
    let smtpPasswordEncrypted = "";
    if (input.smtp?.enabled && input.smtp.password) {
      const secret = String(this.services.config.secret_key ?? "");
      if (!secret) throw new Error("SMTP secrets cannot be stored because the runtime secret key is not configured.");
      smtpPasswordEncrypted = await encryptSecret(input.smtp.password, secret);
    }
    const primaryDomain = input.site.url ? new URL(input.site.url).hostname : "";
    const smtp = input.smtp ?? { enabled: false, host: "", port: 587, encryption: "starttls", username: "", password: "", fromEmail: input.admin.email, fromName: input.site.name };
    const settings = [
      ["deployment_mode", input.deployment],
      ["site_name", input.site.name],
      ["site_title", input.site.name],
      ["site_tagline", "Build. Manage. Evolve."],
      ["site_url", input.site.url ?? ""],
      ["timezone", input.site.timezone ?? "UTC"],
      ["language", input.site.language ?? "en-US"],
      ["cms_version", "2.0.0-alpha.4"],
      ["site_theme", "devone-glass"],
      ["smtp_enabled", smtp.enabled ? "1" : "0"],
      ["smtp_host", smtp.host ?? ""],
      ["smtp_port", String(smtp.port ?? 587)],
      ["smtp_encryption", smtp.encryption ?? "starttls"],
      ["smtp_username", smtp.username ?? ""],
      ["smtp_password_encrypted", smtpPasswordEncrypted],
      ["smtp_from_email", smtp.fromEmail ?? input.admin.email],
      ["smtp_from_name", smtp.fromName ?? input.site.name],
      ["installation_complete", "1"]
    ];
    const statements = DEFAULT_ROLES.map(([name, description, permissions2]) => ({
      sql: "INSERT OR IGNORE INTO roles (name, description, permissions) VALUES (?1, ?2, ?3)",
      params: [name, description, permissions2]
    }));
    statements.push(
      {
        sql: "INSERT INTO users (username, password_hash, email, display_name, role, status, password_changed_at) VALUES (?1, ?2, ?3, ?4, 'administrator', 'active', CURRENT_TIMESTAMP)",
        params: [input.admin.username, hashedPassword, input.admin.email, input.admin.displayName || input.admin.username]
      },
      {
        sql: "INSERT INTO sites (site_name, site_slug, primary_domain, owner_user_id, admin_username, admin_email, status) VALUES (?1, ?2, ?3, (SELECT id FROM users WHERE username = ?4 LIMIT 1), ?4, ?5, 'active')",
        params: [input.site.name, input.site.slug, primaryDomain, input.admin.username, input.admin.email]
      },
      {
        sql: "INSERT INTO site_users (site_id, user_id, role, status) VALUES ((SELECT id FROM sites WHERE site_slug = ?1 LIMIT 1), (SELECT id FROM users WHERE username = ?2 LIMIT 1), 'site_admin', 'active')",
        params: [input.site.slug, input.admin.username]
      },
      {
        sql: "INSERT INTO pages (site_id, slug, title, content, template, show_title, status, author_id) VALUES ((SELECT id FROM sites WHERE site_slug = ?1 LIMIT 1), 'home', ?2, ?3, 'default', 0, 'published', (SELECT id FROM users WHERE username = ?4 LIMIT 1))",
        params: [input.site.slug, input.site.name, "<h1>Welcome to DevOne CMS 2.0</h1><p>Performance, Security, Design.</p>", input.admin.username]
      }
    );
    for (const [key, value] of settings) {
      statements.push({
        sql: "INSERT INTO settings (setting_key, setting_value) VALUES (?1, ?2) ON CONFLICT(setting_key) DO UPDATE SET setting_value = excluded.setting_value",
        params: [key, value]
      });
    }
    await this.services.db.batch(statements);
    const site = await this.services.db.first(
      "SELECT id, owner_user_id FROM sites WHERE site_slug = ?1 LIMIT 1",
      input.site.slug
    );
    const user = await this.services.db.first(
      "SELECT id FROM users WHERE username = ?1 LIMIT 1",
      input.admin.username
    );
    if (!site?.id || !user?.id) throw new Error("Installation completed without required records.");
    return {
      siteId: site.id,
      userId: user.id,
      deployment: input.deployment,
      smtpConfigured: Boolean(input.smtp?.enabled)
    };
  }
};

// core/mail/service.ts
var emailPattern2 = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
var DevOneMailService = class {
  constructor(services2, transport) {
    this.services = services2;
    this.transport = transport;
  }
  services;
  transport;
  async config() {
    const value = async (key, fallback = "") => (await this.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = ?1 LIMIT 1",
      key
    ))?.setting_value ?? fallback;
    const enabled = await value("mail_enabled", await value("smtp_enabled", "0")) === "1";
    const encrypted = await value("smtp_password_encrypted");
    let password = "";
    if (encrypted) {
      const secret = String(this.services.config.secret_key ?? "");
      if (!secret) throw new Error("Mail secret key is not configured.");
      password = await decryptSecret(encrypted, secret);
    }
    return {
      enabled,
      host: await value("smtp_host"),
      port: Number(await value("smtp_port", "587")),
      encryption: await value("smtp_encryption", "starttls"),
      username: await value("smtp_username"),
      password,
      fromEmail: await value("mail_from_email", await value("smtp_from_email")),
      fromName: await value("mail_from_name", await value("smtp_from_name"))
    };
  }
  async send(message) {
    const config = await this.config();
    if (!config.enabled) throw new Error("Mail delivery is disabled.");
    if (!this.transport) throw new Error("No mail transport is available for this runtime.");
    if (!emailPattern2.test(message.to)) throw new Error("Invalid recipient email.");
    if (!message.subject.trim()) throw new Error("Email subject is required.");
    if (!message.text.trim() && !message.html?.trim()) throw new Error("Email body is required.");
    return this.transport.send({
      ...message,
      fromEmail: message.fromEmail ?? config.fromEmail,
      fromName: message.fromName ?? config.fromName
    });
  }
  async test(configOverride) {
    const config = configOverride ?? await this.config();
    if (!config.enabled) throw new Error("Mail delivery is disabled.");
    if (!this.transport) throw new Error("No mail transport is available for this runtime.");
    if (!config.fromEmail || !emailPattern2.test(config.fromEmail)) {
      throw new Error("A valid sender email address is required.");
    }
    if (this.services.config.runtime !== "cloudflare-workers" && (!config.host || !Number.isInteger(config.port) || config.port < 1 || config.port > 65535)) {
      throw new Error("SMTP configuration is incomplete.");
    }
    return this.transport.test();
  }
};

// core/api/index.ts
function createCoreApi(options) {
  const router = new ApiRouter();
  const license = new DevOneLicense(options.licenseProvider ?? new OfflineLicenseProvider());
  const sites = new DevOneSiteService(options.services.db, license);
  const installer = new DevOneInstaller(options.services);
  const mail2 = new DevOneMailService(options.services, options.mailTransport ?? null);
  router.get("/api/install/status", async () => ok({ ok: true, ...await installer.status() }), { public: true });
  router.get("/api/install/prerequisites", async () => {
    const checks = options.installerPrerequisites ? await options.installerPrerequisites() : [{ id: "runtime-secret", label: "Runtime secret key", required: true, ok: Boolean(String(options.services.config.secret_key ?? "")), detail: "Used to protect stored secrets and sessions." }];
    return ok({ ok: checks.every((check) => !check.required || check.ok), checks });
  }, { public: true });
  router.post("/api/install/test-smtp", async (_request, context) => {
    try {
      const status = await installer.status();
      if (status.installed) return fail("Mail testing through the installer is disabled after installation.", 409);
      const body2 = context.body ?? {};
      const hasDraft = Object.keys(body2).length > 0;
      if (hasDraft) {
        const config = {
          enabled: Boolean(body2.enabled),
          host: String(body2.host ?? "").trim(),
          port: Number(body2.port ?? 587),
          encryption: String(body2.encryption ?? "starttls"),
          username: String(body2.username ?? "").trim(),
          password: String(body2.password ?? ""),
          fromEmail: String(body2.fromEmail ?? "").trim().toLowerCase(),
          fromName: String(body2.fromName ?? "").trim()
        };
        if (!options.mailTransportFactory) return fail("This runtime does not support draft mail testing.", 400);
        const draftMail = new DevOneMailService(options.services, options.mailTransportFactory(config));
        await draftMail.test(config);
      } else {
        await mail2.test();
      }
      return ok({ ok: true, message: "Mail transport configuration test succeeded." });
    } catch (error) {
      return fail(error instanceof Error ? error.message : "Mail transport test failed.", 400);
    }
  }, { public: true, csrf: false });
  router.post("/api/install", async (_request, context) => {
    try {
      const body2 = context.body ?? {};
      const result = await installer.install(body2);
      return ok({ ok: true, installed: true, ...result, message: "DevOne CMS 2.0 foundation installed." }, 201);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Installation could not be completed.";
      const status = /already installed|administrator already exists/.test(message) ? 409 : 400;
      return fail(message, status);
    }
  }, { public: true, csrf: false });
  router.get("/api/core/health", async (_request, context) => {
    const installed = await context.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1",
      "installation_complete"
    );
    return ok({ ok: true, product: "DevOne CMS", core_api: "2.0.0", installed: installed?.setting_value === "1" });
  }, { public: true });
  router.get("/api/core/status", async (_request, context) => {
    const version = await context.services.db.first(
      "SELECT setting_value FROM settings WHERE setting_key = ? LIMIT 1",
      "cms_version"
    );
    const entitlement = await license.get();
    return ok({
      ok: true,
      core_api: "2.0.0",
      cms_version: version?.setting_value ?? "2.0.0",
      runtime: String(context.services.config.runtime ?? "provider-independent"),
      license: entitlement ? { edition: entitlement.edition, max_sites: entitlement.maxSites, features: entitlement.features, expires_at: entitlement.expiresAt } : { edition: "single", max_sites: 1, features: [], expires_at: null }
    });
  }, { public: true });
  router.get("/api/core/license", async () => {
    const entitlement = await license.get();
    return ok({ ok: true, licensed: Boolean(entitlement), entitlement });
  }, { public: true });
  router.get("/api/core/content", async (_r, c) => {
    const s = c.siteId ?? (await c.services.db.first("SELECT id FROM sites ORDER BY id ASC LIMIT 1"))?.id ?? null;
    if (!s) return ok({ ok: true, pages: [] });
    return ok({ ok: true, pages: await c.services.db.all("SELECT id,slug,title,content,template,show_title,status,author_id,created_at,updated_at FROM pages WHERE site_id=?1 ORDER BY updated_at DESC,id DESC", s) });
  }, { permission: "content.read" });
  router.post("/api/core/content", async (_r, c) => {
    const b = c.body ?? {}, s = c.siteId ?? (await c.services.db.first("SELECT id FROM sites ORDER BY id ASC LIMIT 1"))?.id ?? null, slug = String(b.slug ?? "").trim().toLowerCase(), title = String(b.title ?? "").trim();
    if (!s || !title || !/^[a-z0-9][a-z0-9-]{0,119}$/.test(slug)) return fail("A valid title and slug are required.", 400);
    try {
      const r = await c.services.db.run("INSERT INTO pages(site_id,slug,title,content,status,author_id) VALUES(?1,?2,?3,?4,?5,?6)", s, slug, title, String(b.content ?? ""), b.status === "draft" ? "draft" : "published", c.user?.id ?? null);
      return ok({ ok: true, page_id: r.lastInsertId }, 201);
    } catch (e) {
      return fail(e instanceof Error ? e.message : "Content could not be created.", 400);
    }
  }, { permission: "content.create" });
  router.get("/api/core/media", async (_r, c) => {
    const s = c.siteId ?? (await c.services.db.first("SELECT id FROM sites ORDER BY id ASC LIMIT 1"))?.id ?? null;
    if (!s) return ok({ ok: true, media: [] });
    return ok({ ok: true, media: await c.services.db.all("SELECT id,filename,object_key,mime_type,size_bytes,alt_text,title,caption,folder,media_type,user_id,created_at,updated_at FROM media WHERE site_id=?1 ORDER BY id DESC", s) });
  }, { permission: "media.read" });
  router.post("/api/core/media", async (_r, c) => {
    const b = c.body ?? {}, s = c.siteId ?? (await c.services.db.first("SELECT id FROM sites ORDER BY id ASC LIMIT 1"))?.id ?? null, d = String(b.data_base64 ?? ""), fn = String(b.filename ?? "").trim(), mime = String(b.mime_type ?? "application/octet-stream").slice(0, 120);
    if (!s || !fn || !d) return fail("Filename and file data are required.", 400);
    if (d.length > 7e6) return fail("Media upload is too large for this request.", 413);
    let bytes;
    try {
      const raw = atob(d.replace(/^data:[^;]+;base64,/, ""));
      bytes = Uint8Array.from(raw, (x) => x.charCodeAt(0));
    } catch {
      return fail("Invalid base64 media data.", 400);
    }
    const safe = fn.replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "") || "upload", key = s + "/" + crypto.randomUUID() + "-" + safe;
    await c.services.media.put(key, bytes, { contentType: mime });
    const r = await c.services.db.run("INSERT INTO media(site_id,filename,object_key,mime_type,size_bytes,alt_text,title,folder,media_type,user_id,updated_at) VALUES(?1,?2,?3,?4,?5,?6,'','other','other',?7,CURRENT_TIMESTAMP)", s, fn, key, mime, bytes.byteLength, c.user?.id ?? null);
    return ok({ ok: true, media_id: r.lastInsertId }, 201);
  }, { permission: "media.create" });
  router.get("/api/core/users", async () => ok({ ok: true, users: await options.services.db.all("SELECT id,username,email,display_name,role,status,created_at,updated_at FROM users ORDER BY id ASC") }), { permission: "users.read" });
  router.post("/api/core/users", async (_r, c) => {
    const b = c.body ?? {}, u = String(b.username ?? "").trim().toLowerCase(), e = String(b.email ?? "").trim().toLowerCase(), p = String(b.password ?? ""), role = String(b.role ?? "subscriber");
    if (!/^[a-z0-9][a-z0-9._-]{2,99}$/.test(u) || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e) || p.length < 12 || p.length > 256) return fail("Username, email, and a 12\u2013256 character password are required.", 400);
    if (!["administrator", "editor", "author", "subscriber", "site_admin"].includes(role)) return fail("Invalid role.", 400);
    if (await c.services.db.first("SELECT id FROM users WHERE lower(username)=lower(?1) LIMIT 1", u)) return fail("That username is already in use.", 409);
    const { passwordHash: passwordHash2 } = await Promise.resolve().then(() => (init_service(), service_exports)), r = await c.services.db.run("INSERT INTO users(username,password_hash,email,display_name,role,status,password_changed_at) VALUES(?1,?2,?3,?4,?5,'active',CURRENT_TIMESTAMP)", u, await passwordHash2(p, Number(c.services.config.password_hash_iterations ?? 1e4)), e, String(b.display_name ?? "").trim() || u, role);
    return ok({ ok: true, user_id: r.lastInsertId }, 201);
  }, { permission: "users.create" });
  router.get("/api/core/settings", async (_r, c) => {
    const site = await c.services.db.first("SELECT id,site_name,site_slug,primary_domain,domain_mode,status,created_at,updated_at FROM sites ORDER BY id ASC LIMIT 1");
    const s = await c.services.db.all("SELECT setting_key,setting_value FROM settings ORDER BY setting_key ASC");
    const siteSettings = site?.id ? await c.services.db.all("SELECT setting_key,setting_value FROM site_settings WHERE site_id=?1 ORDER BY setting_key ASC", Number(site.id)) : [];
    return ok({ ok: true, site, settings: Object.fromEntries(s.map((x) => [x.setting_key, x.setting_value ?? ""])), site_settings: Object.fromEntries(siteSettings.map((x) => [x.setting_key, x.setting_value ?? ""])) });
  }, { permission: "system.read" });
  router.patch("/api/core/settings", async (_r, c) => {
    const site = await c.services.db.first("SELECT id FROM sites ORDER BY id ASC LIMIT 1"), b = c.body ?? {}, v = b.site_settings && typeof b.site_settings === "object" ? b.site_settings : {};
    if (!site) return fail("Site not found.", 404);
    const a = /* @__PURE__ */ new Set(["site_name", "site_tagline", "timezone", "language"]), st = [];
    for (const [k, x] of Object.entries(v)) if (a.has(k) && typeof x === "string") st.push({ sql: "INSERT INTO site_settings(site_id,setting_key,setting_value) VALUES(?1,?2,?3) ON CONFLICT(site_id,setting_key) DO UPDATE SET setting_value=excluded.setting_value", params: [site.id, k, x.trim().slice(0, 1e3)] });
    if (!st.length) return fail("No editable settings supplied.", 400);
    await c.services.db.batch(st);
    return ok({ ok: true });
  }, { permission: "system.manage" });
  router.get("/api/core/sites", async (_request, context) => {
    const rows = await context.services.db.all(
      "SELECT id, site_name, site_slug, primary_domain, owner_user_id, status, created_at, updated_at FROM sites ORDER BY id ASC"
    );
    return ok({ ok: true, sites: rows });
  }, { permission: "sites.read" });
  router.post("/api/core/sites", async (_request, context) => {
    if (!context.user) return fail("Authentication required.", 401);
    if (!await sites.canCreate()) {
      return fail("This installation is limited to one site. A valid Network license is required for additional sites.", 403);
    }
    const body2 = context.body ?? {};
    const siteName = String(body2.site_name ?? "").trim();
    const siteSlug = String(body2.site_slug ?? "").trim().toLowerCase();
    const primaryDomain = String(body2.primary_domain ?? "").trim();
    if (siteName.length < 2 || !/^[a-z0-9][a-z0-9-]{1,119}$/.test(siteSlug)) {
      return fail("Invalid site name or slug.", 400);
    }
    try {
      const id = await sites.create({ siteName, siteSlug, ownerUserId: context.user.id, primaryDomain });
      return ok({ ok: true, site_id: id }, 201);
    } catch (error) {
      return fail(error instanceof Error ? error.message : "Site could not be created.", 403);
    }
  }, { permission: "sites.create" });
  return { router, api: new DevOneApi(router, options) };
}

// core/auth/permissions.ts
function parsePermissionList(value) {
  if (!value) return [];
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed.filter((item) => typeof item === "string") : [];
  } catch {
    return [];
  }
}
function permissionMatches(granted, required) {
  if (granted === "*") return true;
  if (granted === required) return true;
  if (granted.endsWith(".*")) return required.startsWith(granted.slice(0, -1));
  return false;
}
var DevOnePermissions = class {
  constructor(db) {
    this.db = db;
  }
  db;
  async has(user, permission, siteId = null) {
    if (!user || user.status !== "active") return false;
    if (user.role === "administrator") return true;
    const role = await this.db.first(
      "SELECT permissions FROM roles WHERE name = ?1 LIMIT 1",
      user.role
    );
    const granted = parsePermissionList(role?.permissions);
    const override = await this.db.first(
      "SELECT permissions_override FROM users WHERE id = ?1 LIMIT 1",
      user.id
    );
    const extra = parsePermissionList(override?.permissions_override);
    const allowed = [...granted, ...extra].some((item) => permissionMatches(item, permission));
    if (!allowed) return false;
    if (!siteId || user.role === "administrator") return true;
    const membership = await this.db.first(
      "SELECT id FROM site_users WHERE site_id = ?1 AND user_id = ?2 AND status = 'active' LIMIT 1",
      siteId,
      user.id
    );
    return Boolean(membership);
  }
  async require(user, permission, siteId = null) {
    if (!await this.has(user, permission, siteId)) throw new Error("Permission denied.");
  }
};

// core/auth/index.ts
init_service();

// adapters/local/mail.ts
import { connect as tlsConnect } from "node:tls";
import { connect as tcpConnect } from "node:net";
function readResponse(socket) {
  return new Promise((resolve5, reject) => {
    let buffer = "";
    const onData = (chunk) => {
      buffer += chunk.toString("utf8");
      const lines = buffer.split(/\r?\n/).filter((line) => line.length > 0);
      const last = lines[lines.length - 1];
      if (last && /^\d{3} /.test(last)) {
        cleanup();
        resolve5(lines.join("\n"));
      }
    };
    const onError = (error) => {
      cleanup();
      reject(error);
    };
    const cleanup = () => {
      socket.off("data", onData);
      socket.off("error", onError);
    };
    socket.on("data", onData);
    socket.once("error", onError);
  });
}
async function command(socket, value) {
  socket.write(value + "\r\n");
  return readResponse(socket);
}
function header(value) {
  return value.replace(/[\r\n]/g, "");
}
function body(message) {
  const from = message.fromName ? '"' + message.fromName.replace(/"/g, "'") + '" <' + (message.fromEmail ?? "") + ">" : message.fromEmail ?? "";
  const lines = [
    "From: " + header(from),
    "To: " + header(message.to),
    "Subject: " + header(message.subject),
    "MIME-Version: 1.0",
    "Content-Type: text/plain; charset=UTF-8"
  ];
  if (message.replyTo) lines.push("Reply-To: " + header(message.replyTo));
  return lines.join("\r\n") + "\r\n\r\n" + message.text.replace(/\r?\n/g, "\r\n");
}
var LocalSmtpTransport = class {
  constructor(configSource) {
    this.configSource = configSource;
  }
  configSource;
  async config() {
    return typeof this.configSource === "function" ? await this.configSource() : this.configSource;
  }
  async connection() {
    const config = await this.config();
    if (config.encryption === "tls") {
      return new Promise((resolve5, reject) => {
        const socket = tlsConnect({ host: config.host, port: config.port, servername: config.host });
        socket.once("secureConnect", () => resolve5(socket));
        socket.once("error", reject);
      });
    }
    return new Promise((resolve5, reject) => {
      const socket = tcpConnect(config.port, config.host, () => resolve5(socket));
      socket.once("error", reject);
    });
  }
  async authenticate(socket, config) {
    if (!config.username) return;
    const value = Buffer.from("\0" + config.username + "\0" + config.password).toString("base64");
    const response = await command(socket, "AUTH PLAIN " + value);
    if (!/^2/.test(response)) throw new Error("SMTP authentication failed.");
  }
  async sendOn(socket, message, config) {
    let response = await readResponse(socket);
    if (!/^2/.test(response)) throw new Error("SMTP server rejected the connection.");
    response = await command(socket, "EHLO devone.local");
    if (!/^2/.test(response)) throw new Error("SMTP EHLO failed.");
    await this.authenticate(socket, config);
    response = await command(socket, "MAIL FROM:<" + header(message.fromEmail ?? config.fromEmail) + ">");
    if (!/^2/.test(response)) throw new Error("SMTP MAIL FROM failed.");
    response = await command(socket, "RCPT TO:<" + header(message.to) + ">");
    if (!/^2/.test(response)) throw new Error("SMTP recipient rejected.");
    response = await command(socket, "DATA");
    if (!/^3/.test(response)) throw new Error("SMTP DATA failed.");
    socket.write(body(message).replace(/^\./gm, "..") + "\r\n.\r\n");
    response = await readResponse(socket);
    if (!/^2/.test(response)) throw new Error("SMTP message rejected.");
    await command(socket, "QUIT");
    socket.end();
    return { messageId: crypto.randomUUID() };
  }
  async send(message) {
    const config = await this.config();
    const socket = await this.connection();
    try {
      if (config.encryption === "starttls") {
        let response = await readResponse(socket);
        if (!/^2/.test(response)) throw new Error("SMTP server rejected the connection.");
        response = await command(socket, "EHLO devone.local");
        if (!/^2/.test(response)) throw new Error("SMTP EHLO failed.");
        response = await command(socket, "STARTTLS");
        if (!/^2/.test(response)) throw new Error("SMTP STARTTLS failed.");
        const secure = await new Promise((resolve5, reject) => {
          const tls = tlsConnect({ socket, servername: config.host });
          tls.once("secureConnect", () => resolve5(tls));
          tls.once("error", reject);
        });
        return await this.sendOn(secure, message, config);
      }
      return await this.sendOn(socket, message, config);
    } catch (error) {
      socket.destroy();
      throw error;
    }
  }
  async test() {
    const config = await this.config();
    const socket = await this.connection();
    try {
      let response = await readResponse(socket);
      if (!/^2/.test(response)) throw new Error("SMTP server rejected the connection.");
      response = await command(socket, "EHLO devone.local");
      if (!/^2/.test(response)) throw new Error("SMTP EHLO failed.");
      if (config.encryption === "starttls") {
        response = await command(socket, "STARTTLS");
        if (!/^2/.test(response)) throw new Error("SMTP STARTTLS failed.");
      }
      await command(socket, "QUIT");
      socket.end();
      return { ok: true };
    } catch (error) {
      socket.destroy();
      throw error;
    }
  }
};

// runtime/local-server.ts
process.umask(63);
var production = process.env.NODE_ENV === "production";
var canonical = production ? new URL(process.env.DEVONE_SITE_URL ?? "") : null;
if (canonical && (canonical.protocol !== "https:" || canonical.origin !== process.env.DEVONE_SITE_URL)) throw Error("Production requires a canonical HTTPS site URL.");
var publicDir = resolve4(process.env.DEVONE_PUBLIC_DIR ?? fileURLToPath2(new URL("./web/", import.meta.url)));
if (import.meta.url.endsWith("/runtime.mjs") && !process.env.DEVONE_MIGRATIONS_DIR) process.env.DEVONE_MIGRATIONS_DIR = fileURLToPath2(new URL("./migrations/", import.meta.url));
var port = Number(process.env.PORT ?? 8080);
var host = process.env.HOST ?? "127.0.0.1";
if (production && host !== "127.0.0.1") throw Error("Production CMS must listen on loopback behind a trusted proxy.");
var services = await createLocalRuntime({
  dataDir: process.env.DEVONE_DATA_DIR ?? "./data",
  mediaDir: process.env.DEVONE_MEDIA_DIR,
  environment: process.env.NODE_ENV ?? "development"
});
var auth = new DevOneAuthService(services.db, { secureCookies: production, passwordHashIterations: production ? 6e5 : 1e4 });
if (production && !await services.db.first("SELECT setting_value FROM settings WHERE setting_key='installation_complete' AND setting_value='1'")) throw Error("Initialize the production CMS offline before starting the web service.");
var permissions = new DevOnePermissions(services.db);
var mail;
var mailTransport = new LocalSmtpTransport(async () => mail.config());
mail = new DevOneMailService(services, mailTransport);
var core = createCoreApi({
  services,
  authenticate: (request) => auth.getCurrentUser(request),
  authorize: (user, permission, siteId) => permissions.has(user, permission, siteId),
  resolveSite: async (request) => {
    const value = request.headers.get("x-devone-site-id");
    return value && /^\d+$/.test(value) ? Number(value) : null;
  },
  mailTransport,
  mailTransportFactory: (config) => new LocalSmtpTransport(config),
  validateCsrf: async (request) => {
    try {
      await auth.requireCsrf(request);
      return true;
    } catch {
      return false;
    }
  }
});
function json(value, status = 200, headers = {}) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...headers }
  });
}
async function readBody(request) {
  const value = await request.json().catch(() => null);
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}
async function routeAuth(request, path) {
  if (path === "/api/auth/login" && request.method === "POST") {
    const body2 = await readBody(request);
    try {
      const result = await auth.login(request, String(body2.username ?? ""), String(body2.password ?? ""));
      return json({ ok: true, user: result.user, csrf_token: result.csrfToken, expires_at: result.expiresAt }, 200, { "set-cookie": result.sessionCookie });
    } catch (error) {
      return json({ ok: false, error: error instanceof Error ? error.message : "Invalid credentials." }, authErrorStatus(error));
    }
  }
  if (path === "/api/auth/logout" && request.method === "POST") {
    try {
      const cookie = await auth.logout(request);
      return json({ ok: true }, 200, { "set-cookie": cookie });
    } catch (error) {
      return json({ ok: false, error: error instanceof Error ? error.message : "Authentication failed." }, authErrorStatus(error));
    }
  }
  if (path === "/api/auth/me" && request.method === "GET") {
    const session = await auth.restoreSession(request);
    return json({ ok: true, authenticated: Boolean(session.user), user: session.user, csrf_token: session.csrfToken });
  }
  return null;
}
async function staticAsset(request, path) {
  if (!["GET", "HEAD"].includes(request.method)) return json({ ok: false, error: "Method not allowed." }, 405);
  let decoded;
  try {
    decoded = decodeURIComponent(path);
  } catch {
    return json({ ok: false, error: "Invalid path." }, 400);
  }
  if (decoded.includes("\\") || decoded.split("/").some((p) => p === ".." || p.startsWith("."))) return json({ ok: false, error: "Not found." }, 404);
  const asset = decoded.startsWith("/assets/");
  if (!asset && decoded !== "/" && decoded !== "/index.html") return json({ ok: false, error: "Not found." }, 404);
  const file = resolve4(publicDir, "." + (decoded === "/" ? "/index.html" : decoded));
  if (!file.startsWith(publicDir + "/")) return json({ ok: false, error: "Not found." }, 404);
  try {
    const handle2 = await open2(file, constants2.O_RDONLY | constants2.O_NOFOLLOW);
    try {
      const stat2 = await handle2.stat();
      if (!stat2.isFile() || stat2.size > 5 * 1024 * 1024) throw Error();
      const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png", ".webp": "image/webp" };
      const type = types[extname(file)];
      if (!type) throw Error();
      return new Response(request.method === "HEAD" ? null : new Uint8Array(await handle2.readFile()), { headers: { "Content-Type": type, "Cache-Control": asset ? "public, max-age=31536000, immutable" : "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY" } });
    } finally {
      await handle2.close();
    }
  } catch {
    return json({ ok: false, error: "Not found." }, 404);
  }
}
async function handle(request) {
  const url = new URL(request.url);
  const path = url.pathname.replace(/\/+$/, "") || "/";
  if (production && !["GET", "HEAD"].includes(request.method)) {
    if (path.startsWith("/api/install")) return json({ ok: false, error: "Production setup is disabled." }, 403);
    if (request.headers.get("x-forwarded-proto") !== "https") return json({ ok: false, error: "HTTPS is required." }, 426);
    if (request.headers.get("origin") !== canonical.origin) return json({ ok: false, error: "Same-origin confirmation is required." }, 403);
  }
  const authResponse = await routeAuth(request, path);
  if (authResponse) return authResponse;
  if (path.startsWith("/api/core/") || path.startsWith("/api/install")) return core.api.handle(request);
  if (path === "/api/health" && request.method === "GET") return json({ ok: true, product: "DevOne CMS", version: "2.0.0-alpha.4", runtime: "local", database: "sqlite", media: "filesystem", cache: "memory" });
  if (path === "/api/runtime/status" && request.method === "GET") {
    if (production && !await auth.getCurrentUser(request)) return json({ ok: false, error: "Authentication required." }, 401);
    const migrations = await services.db.all("SELECT name, applied_at FROM devone_migrations ORDER BY name");
    return json({ ok: true, runtime: services.config.runtime, migrations });
  }
  if (!path.startsWith("/api/")) return staticAsset(request, path);
  return json({ ok: false, error: "API route not found." }, 404);
}
var loginAttempts = /* @__PURE__ */ new Map();
var rateTimer = setInterval(() => {
  for (const [key, value] of loginAttempts) if (value.until < Date.now()) loginAttempts.delete(key);
}, 6e4);
rateTimer.unref();
var server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url ?? "/", "http://" + (req.headers.host ?? "localhost"));
    if (production && url.pathname === "/api/auth/login" && req.method === "POST") {
      const ip = String(req.headers["x-real-ip"] ?? req.socket.remoteAddress ?? "local");
      const now = Date.now(), attempt = loginAttempts.get(ip) ?? { count: 0, until: now + 6e4 };
      if (attempt.until <= now) {
        attempt.count = 0;
        attempt.until = now + 6e4;
      }
      if (attempt.count >= 10 || !loginAttempts.has(ip) && loginAttempts.size >= 1e3) {
        res.writeHead(429, { "content-type": "application/json", "cache-control": "no-store" });
        res.end(JSON.stringify({ ok: false, error: "Try again later." }));
        return;
      }
      attempt.count++;
      loginAttempts.set(ip, attempt);
    }
    const chunks = [];
    let totalBytes = 0;
    const maxBytes = 2 * 1024 * 1024;
    for await (const chunk of req) {
      const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
      totalBytes += buffer.length;
      if (totalBytes > maxBytes) {
        res.writeHead(413, { "content-type": "application/json", "cache-control": "no-store" });
        res.end(JSON.stringify({ ok: false, error: "Request body is too large.", code: "body_too_large" }));
        req.destroy();
        return;
      }
      chunks.push(buffer);
    }
    const request = new Request(url, {
      method: req.method,
      headers: Object.fromEntries(Object.entries(req.headers).flatMap(([key, value]) => value === void 0 ? [] : [[key, Array.isArray(value) ? value.join(", ") : value]])),
      body: chunks.length && req.method !== "GET" && req.method !== "HEAD" ? Buffer.concat(chunks) : void 0
    });
    const response = await handle(request);
    res.writeHead(response.status, Object.fromEntries(response.headers.entries()));
    res.end(response.body ? Buffer.from(await response.arrayBuffer()) : void 0);
  } catch (error) {
    console.error("cms_request_failed");
    res.writeHead(500, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: false, error: "Internal server error." }));
  }
});
server.listen(port, host, () => console.log("DevOne local runtime: http://" + host + ":" + port));
